﻿using System;

namespace Spice.Models
{
    internal class ForeignkeyAttribute : Attribute
    {
    }
}